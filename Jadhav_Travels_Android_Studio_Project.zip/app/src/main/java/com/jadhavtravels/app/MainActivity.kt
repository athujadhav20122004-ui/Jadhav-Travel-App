package com.jadhavtravels.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val red = Color.rgb(210, 45, 52)
    private val prefs by lazy { getSharedPreferences("jadhav_travels", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun setup(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 22)
            setBackgroundColor(Color.WHITE)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 25f
            setTextColor(red)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(heading)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun field(hint: String): EditText {
        val e = EditText(this).apply {
            this.hint = hint
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 8, 14, 8)
        }
        root.addView(e, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        return e
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setTextColor(Color.WHITE)
            setBackgroundColor(red)
            textSize = 15f
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
    }

    private fun note(text: String) {
        root.addView(TextView(this).apply {
            this.text = text
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(4, 8, 4, 12)
        })
    }

    private fun showHome() {
        setup("JADHAV TRAVEL'S")
        note("रत्नागिरी आणि आसपास • Ertiga with Driver\nTravel Safe. Travel Smart.")
        button("बुकिंग करा / Book a Ride") { showBooking() }
        button("Admin Panel") { showAdminLogin() }
        note("दर: ₹14 प्रति KM | लोकल पॅकेज: ₹3,000 (8 तास / 80 KM)\nटोल, पार्किंग व लागू अतिरिक्त शुल्क वेगळे. अंतिम भाडे मालकाकडून निश्चित होईल.")
    }

    private fun showBooking() {
        setup("बुकिंग / Booking")
        val name = field("ग्राहकाचे नाव / Customer name")
        val phone = field("मोबाईल नंबर / Mobile number")
        val pickup = field("कुठून? / Pickup location")
        val drop = field("कुठे? / Destination")
        val date = field("तारीख / Date (उदा. 25-11-2026)")
        val time = field("वेळ / Time")
        val type = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("प्रति KM", "लोकल पॅकेज – 8 तास / 80 KM"))
        }
        root.addView(type)
        button("बुकिंग विनंती सेव्ह करा") {
            if (name.text.isBlank() || phone.text.isBlank() || pickup.text.isBlank() || drop.text.isBlank() || date.text.isBlank()) {
                Toast.makeText(this, "कृपया आवश्यक माहिती भरा", Toast.LENGTH_LONG).show()
                return@button
            }
            val item = JSONObject().apply {
                put("name", name.text.toString()); put("phone", phone.text.toString())
                put("pickup", pickup.text.toString()); put("drop", drop.text.toString())
                put("date", date.text.toString()); put("time", time.text.toString())
                put("type", type.selectedItem.toString()); put("status", "Pending")
            }
            val arr = JSONArray(prefs.getString("bookings", "[]"))
            arr.put(item)
            prefs.edit().putString("bookings", arr.toString()).apply()
            Toast.makeText(this, "बुकिंग या फोनमध्ये सेव्ह झाली!", Toast.LENGTH_LONG).show()
            showHome()
        }
        button("मागे / Back") { showHome() }
        note("ही पहिली आवृत्ती बुकिंग या फोनमध्ये स्थानिकरित्या सेव्ह करते. ऑनलाइन सर्व्हर/WhatsApp सूचना जोडलेल्या नाहीत.")
    }

    private fun showAdminLogin() {
        setup("Admin Login")
        val pin = field("Admin PIN (डेमो PIN: 2468)")
        button("Login") {
            if (pin.text.toString() == "2468") showAdmin()
            else Toast.makeText(this, "चुकीचा PIN", Toast.LENGTH_SHORT).show()
        }
        button("मागे / Back") { showHome() }
        note("सुरक्षेसाठी डेमो PIN वापरू नका; प्रत्यक्ष वापरापूर्वी PIN बदला.")
    }

    private fun showAdmin() {
        setup("Admin Dashboard")
        val arr = JSONArray(prefs.getString("bookings", "[]"))
        note("एकूण बुकिंग: ${arr.length()}")
        for (i in arr.length() - 1 downTo 0) {
            val o = arr.getJSONObject(i)
            note("${o.optString("name")} • ${o.optString("phone")}\n${o.optString("pickup")} → ${o.optString("drop")}\n${o.optString("date")} ${o.optString("time")}\n${o.optString("type")} • ${o.optString("status")}")
        }
        if (arr.length() == 0) note("अजून बुकिंग आलेली नाही.")
        button("WhatsApp उघडा") {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"))
            startActivity(intent)
        }
        button("Home") { showHome() }
    }
}
